import unittest, io
from openpyxl import load_workbook
from evalengine.exam import normalize_exam, pick_counted, finalize
from evalengine.grading import process_sheet
from evalengine.export import build_workbook
from evalengine.llm import MockLLM


def exam(n=2, policy="best"):
    return normalize_exam({"title": "T", "required_count": n, "extra_policy": policy, "questions": [
        {"id": f"Q{i}", "question": f"question {i}", "max_marks": 10} for i in range(1, 5)]})


def llm(answers):
    ext = {"question_intent": "", "claims": [], "contradictions": [], "ocr_uncertainties": [], "injection_detected": False}
    sc = {"criteria": [{"criterion": "Overall correctness and completeness", "marks_awarded": 6, "correctness": "correct"}]}
    return MockLLM({"read_sheet": {"student_name": "Asha", "student_id": "S1", "answers": answers},
                    "extract": ext, "score": sc, "fairness": {"issues": [], "pass": True}})


class T(unittest.TestCase):
    def test_validation(self):
        with self.assertRaises(ValueError): normalize_exam({"questions": [{"question": "x", "max_marks": 5,
                     "rubric": [{"criterion": "a", "max_marks": 3}]}]})
        with self.assertRaises(ValueError): normalize_exam({"required_count": 9, "questions": [{"question": "x", "max_marks": 5}]})
        self.assertEqual(exam(2)["total_marks"], 20)

    def test_pick_counted(self):
        att = [("Q1", 3), ("Q2", 9), ("Q3", 9), ("Q4", 1)]
        self.assertEqual(pick_counted(att, 2, "best"), {"Q2", "Q3"})
        self.assertEqual(pick_counted(att, 2, "first"), {"Q1", "Q2"})
        self.assertEqual(pick_counted(att[:1], 2, "best"), {"Q1"})

    def test_process_and_result(self):
        ex = exam(2); sh = {"questions": {}}
        process_sheet(ex, sh, llm([{"question_id": "Q1", "text": "a"}, {"question_id": "3", "text": "b"},
                                   {"question_id": "Q9", "text": "c"}]), b"%PDF", 1)
        self.assertEqual(sh["total"], 12); self.assertEqual(sh["percent"], 60.0); self.assertEqual(sh["result"], "PASS")
        self.assertEqual(sh["student_name"], "Asha"); self.assertTrue(sh["needs_review"])  # unknown Q9 warning

    def test_fail_and_edit(self):
        ex = exam(2); sh = {"questions": {}}
        process_sheet(ex, sh, llm([{"question_id": "Q1", "text": "a"}]), b"%PDF", 1)
        self.assertEqual((sh["total"], sh["result"]), (6, "FAIL"))
        sh["questions"]["Q1"]["marks"] = 10; finalize(sh, ex)
        self.assertEqual(sh["result"], "PASS")   # 10/20 = 50% >= 40

    def test_excel(self):
        ex = exam(2); a, b = {"questions": {}, "id": "a", "status": "done"}, {"questions": {}, "id": "b", "status": "done"}
        process_sheet(ex, a, llm([{"question_id": "Q1", "text": "a"}]), b"%PDF", 1)                # 6/20 fail
        process_sheet(ex, b, llm([{"question_id": q, "text": "x"} for q in ("Q1", "Q2", "Q3")]), b"%PDF", 1)
        b["questions"]["Q1"]["marks"] = b["questions"]["Q2"]["marks"] = 10; finalize(b, ex)         # 100%
        ws = load_workbook(io.BytesIO(build_workbook(ex, [a, b])))["Marks"]
        rows = list(ws.iter_rows(min_row=3, values_only=True))
        self.assertEqual(rows[0][-2], "FAIL"); self.assertIn("Good", rows[1][-2])
        fills = {r[0].fill.fgColor.rgb[-6:] for r in ws.iter_rows(min_row=3, max_row=4)}
        self.assertTrue({"F8CBCB", "CDEBD3"} <= fills)


if __name__ == "__main__": unittest.main()
