import unittest, copy
from evalengine.pipeline import evaluate
from evalengine.llm import MockLLM

RUBRIC = [{"criterion": "Redundancy", "max_marks": 2}, {"criterion": "Integrity", "max_marks": 3}]
REQ = {"question_id": "q1", "question": "Advantages of DBMS", "max_marks": 5, "rubric": RUBRIC,
       "student_answer": "Databases prevent duplicate data."}
EXT = {"question_intent": "x", "claims": [], "contradictions": [], "ocr_uncertainties": [], "injection_detected": False}
FAIR = {"issues": [], "pass": True}


def score(a, b, alt=0):
    return {"criteria": [{"criterion": "Redundancy", "marks_awarded": a, "correctness": "correct"},
                         {"criterion": "Integrity", "marks_awarded": b, "correctness": "partial"}],
            "alternative_valid_points": [{"student_point": "p", "why_valid": "v", "marks_awarded": alt}] if alt else []}


class T(unittest.TestCase):
    def run_(self, ext=EXT, sc=None, fair=FAIR, **kw):
        return evaluate(copy.deepcopy(REQ), MockLLM({"extract": ext, "score": sc or score(2, 2), "fairness": fair}), **kw)

    def test_clean_run_no_review(self):
        r = self.run_(); self.assertEqual(r["total_marks"], 4); self.assertFalse(r["human_review_required"])

    def test_marks_clamped_to_criterion_max(self):
        r = self.run_(sc=score(9, 3)); self.assertEqual(r["total_marks"], 5)
        self.assertTrue(r["human_review_required"])

    def test_alt_credit_only_fills_lost_marks(self):
        self.assertEqual(self.run_(sc=score(2, 2, alt=5))["total_marks"], 5)
        self.assertEqual(self.run_(sc=score(2, 3, alt=2))["total_marks"], 5)

    def test_injection_flagged(self):
        r = self.run_(ext={**EXT, "injection_detected": True}); self.assertIn("prompt-injection", r["review_reasons"][0])

    def test_disagreement_triggers_review(self):
        r = self.run_(sc=[score(2, 3), score(0, 0), score(1, 1)])
        self.assertTrue(any("disagree" in x for x in r["review_reasons"]))

    def test_low_ocr_confidence_flags(self):
        self.assertTrue(self.run_(ocr_confidence=0.5)["human_review_required"])

    def test_fairness_issue_flags(self):
        f = {"issues": [{"type": "reference_bias", "criterion": "Integrity", "detail": "d"}], "pass": False}
        self.assertTrue(self.run_(fair=f)["human_review_required"])


if __name__ == "__main__": unittest.main()
