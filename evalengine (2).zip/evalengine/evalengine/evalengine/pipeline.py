import json, statistics
from .llm import LLM
from . import prompts
from .validate import enforce


def _user(req: dict, extra: str = "") -> str:
    rub = json.dumps(req["rubric"], indent=1)
    return (f"SUBJECT: {req.get('subject','')}\nQUESTION TYPE: {req.get('question_type','')}\n"
            f"QUESTION: {req['question']}\nMAX MARKS: {req['max_marks']}\nRUBRIC:\n{rub}\n"
            f"REFERENCE ANSWER (guide only):\n{req.get('reference_answer','(none)')}\n"
            f"<student_answer>\n{req['student_answer']}\n</student_answer>\n{extra}")


def evaluate(req: dict, llm: LLM, runs: int = 3, ocr_confidence: float = 1.0,
             ocr_threshold: float = 0.8, spread_threshold: float = 0.15) -> dict:
    """req keys: question_id, question, max_marks, rubric[{criterion,max_marks,description}],
    reference_answer, student_answer, subject, question_type."""
    mx = req["max_marks"]
    ext = llm.complete_json("extract", prompts.EXTRACT, _user(req))
    ctx = "EXTRACTED CLAIMS:\n" + json.dumps(ext.get("claims", []), indent=1)

    scored = [enforce(llm.complete_json("score", prompts.SCORE, _user(req, ctx)), req["rubric"], mx)
              for _ in range(runs)]
    totals = [s["total_marks"] for s in scored]
    med = statistics.median(totals)
    final = min(scored, key=lambda s: abs(s["total_marks"] - med))  # representative run
    spread = max(totals) - min(totals)

    fair = llm.complete_json("fairness", prompts.FAIRNESS,
                             _user(req, "PROPOSED SCORE:\n" + json.dumps(final, indent=1)))

    reasons = []
    if ext.get("injection_detected"): reasons.append("possible prompt-injection in student answer")
    if ocr_confidence < ocr_threshold or ext.get("ocr_uncertainties"): reasons.append("OCR uncertainty")
    if ext.get("contradictions"): reasons.append("student contradicts themselves")
    if spread > spread_threshold * mx: reasons.append(f"scoring runs disagree (spread {spread})")
    if fair.get("issues"): reasons.append("fairness audit raised issues")
    if final["validation_warnings"]: reasons.append("model output needed correction")
    if any(c["correctness"] == "ambiguous" for c in final["criteria"]): reasons.append("ambiguous criteria")

    # Confidence from objective signals, not model self-report.
    conf = max(0.0, min(1.0, 1 - spread / mx - 0.15 * len(fair.get("issues", []))
                        - (1 - ocr_confidence) - 0.1 * len(final["validation_warnings"])))
    return {
        "question_id": req.get("question_id"), "maximum_marks": mx,
        "total_marks": final["total_marks"], "run_totals": totals,
        "evaluation": {"question_intent": ext.get("question_intent"), "claims": ext.get("claims", []),
                       **{k: final.get(k) for k in ("criteria", "alternative_valid_points", "errors",
                                                    "missing_concepts", "student_feedback",
                                                    "validation_warnings")}},
        "contradictions": ext.get("contradictions", []),
        "ocr_uncertainties": ext.get("ocr_uncertainties", []),
        "fairness": fair, "confidence": round(conf, 2),
        "human_review_required": bool(reasons), "review_reasons": reasons, "status": "pending_review",
    }
