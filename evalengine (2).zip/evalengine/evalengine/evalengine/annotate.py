"""Stamps marks onto the student's original PDF and appends a summary page."""
import io
from xml.sax.saxutils import escape
from pypdf import PdfReader, PdfWriter
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle

RED = colors.HexColor("#C0261B")
GAP = 26  # minimum vertical gap between stamps on a page


def _g(x): return f"{x:g}"


def _badge(c, W, y, text, size=12):
    tw = c.stringWidth(text, "Helvetica-Bold", size); pad = 4
    x = W - tw - 2 * pad - 10
    c.setFillColor(colors.white); c.setStrokeColor(RED); c.setLineWidth(1.3)
    c.roundRect(x, y - pad, tw + 2 * pad, size + 2 * pad, 4, fill=1, stroke=1)
    c.setFillColor(RED); c.setFont("Helvetica-Bold", size); c.drawString(x + pad, y + 1, text)


def _stamps(exam, sheet, n_pages):
    """-> {page_index: [(fraction_from_top, text, big)]}"""
    out = {i: [] for i in range(n_pages)}
    out[0].append((0.02, f"TOTAL {_g(sheet['total'])} / {_g(sheet['max_total'])}   {sheet['result']}", True))
    for k, q in enumerate(exam["questions"]):
        d = sheet["questions"].get(q["id"])
        if not d or not d.get("attempted"): continue
        loc = d.get("loc") or {}
        try: pg = min(max(int(loc.get("page") or 1) - 1, 0), n_pages - 1)
        except (TypeError, ValueError): pg = 0
        try: fy = min(max(float(loc.get("y")), 0.03), 0.95)
        except (TypeError, ValueError): fy = 0.10 + 0.07 * k       # no location: stack in the margin
        t = f"{q['id']}  {_g(d['marks'])}/{_g(d['max'])}" + ("" if d.get("counted") else "  (not counted)")
        out[pg].append((fy, t, False))
    return out


def _summary_pdf(exam, sheet) -> bytes:
    ss = getSampleStyleSheet(); N = ParagraphStyle("n", parent=ss["Normal"], fontSize=10, leading=13)
    st = [Paragraph("Marking summary", ss["Title"]),
          Paragraph(f"<b>Student:</b> {escape(sheet.get('student_name') or sheet.get('filename',''))} &nbsp; "
                    f"<b>ID:</b> {escape(sheet.get('student_id') or '-')} &nbsp; <b>Exam:</b> {escape(exam['title'])}", N),
          Paragraph(f"<b>Total:</b> {_g(sheet['total'])} / {_g(sheet['max_total'])} ({sheet['percent']}%) &nbsp; "
                    f"<b>Result:</b> {sheet['result']}{' (good marks)' if sheet['good'] else ''}", N), Spacer(1, 6)]
    for note in sheet.get("notes", []): st.append(Paragraph("Note: " + escape(note), N))
    rows = [["Q", "Marks", "Counted", "Comment"]]
    for q in exam["questions"]:
        d = sheet["questions"].get(q["id"])
        if not d or not d.get("attempted"): rows.append([q["id"], "-", "-", Paragraph("Not attempted", N)]); continue
        cm = d["result"]["evaluation"].get("student_feedback", "")
        if d.get("flagged") and not d.get("edited"): cm += " [Teacher check suggested: " + "; ".join(d.get("reasons", [])) + "]"
        if d.get("edited"): cm += " [Marks adjusted by teacher]"
        rows.append([q["id"], f"{_g(d['marks'])}/{_g(d['max'])}", "Yes" if d.get("counted") else "No", Paragraph(escape(cm), N)])
    t = Table(rows, colWidths=[35, 55, 55, 360], repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F3A5F")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                           ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#BBBBBB")), ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    st += [Spacer(1, 8), t, Spacer(1, 12), Paragraph("<i>Marks were proposed by an AI system and are subject to teacher review.</i>", N)]
    buf = io.BytesIO(); SimpleDocTemplate(buf, pagesize=A4, leftMargin=40, rightMargin=40, topMargin=40, bottomMargin=40).build(st)
    return buf.getvalue()


def annotate_pdf(pdf: bytes, exam: dict, sheet: dict) -> bytes:
    reader = PdfReader(io.BytesIO(pdf)); writer = PdfWriter(); n = len(reader.pages)
    stamps = _stamps(exam, sheet, n)
    for i, page in enumerate(reader.pages):
        try: page.transfer_rotation_to_content()
        except Exception: pass
        b = page.mediabox; W, H, x0, y0 = float(b.width), float(b.height), float(b.left), float(b.bottom)
        buf = io.BytesIO(); c = canvas.Canvas(buf, pagesize=(W, H)); c.translate(x0, y0)
        last = None
        for fy, text, big in sorted(stamps[i], key=lambda s: s[0]):
            y = H - fy * H - 12
            if last is not None and y > last - GAP: y = last - GAP        # avoid overlapping stamps
            y = max(y, 30); last = y
            _badge(c, W, y, text, 14 if big else 12)
        c.save(); buf.seek(0)
        page.merge_page(PdfReader(buf).pages[0]); writer.add_page(page)
    for p in PdfReader(io.BytesIO(_summary_pdf(exam, sheet))).pages: writer.add_page(p)
    out = io.BytesIO(); writer.write(out); return out.getvalue()
