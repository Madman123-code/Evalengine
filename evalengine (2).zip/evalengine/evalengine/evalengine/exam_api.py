"""Exam / answer-sheet routes. Included by api.py."""
import json, os, pathlib, threading, uuid, time
from concurrent.futures import ThreadPoolExecutor
from fastapi import APIRouter, HTTPException, UploadFile, File, Form
from fastapi.responses import Response, FileResponse
from pydantic import BaseModel
from .exam import normalize_exam, finalize
from .grading import process_sheet
from .export import build_workbook
from .llm import make_llm

router = APIRouter()
DATA = pathlib.Path(os.getenv("EVAL_DATA", "data")); (DATA / "pdfs").mkdir(parents=True, exist_ok=True)
DB = DATA / "exams.json"
LOCK = threading.RLock()
EXAMS: dict = json.loads(DB.read_text()) if DB.exists() else {}
POOL = ThreadPoolExecutor(max_workers=int(os.getenv("EVAL_WORKERS", "1")))  # keep low on free tiers
_llm = None

for e in EXAMS.values():   # jobs killed by a restart
    for s in e["sheets"].values():
        if s["status"] in ("queued", "processing"): s.update(status="failed", error="Interrupted by restart. Press Retry.")


def save():
    with LOCK: DB.write_text(json.dumps(EXAMS))


def llm():
    global _llm
    _llm = _llm or make_llm(); return _llm


def get_exam(eid):
    if eid not in EXAMS: raise HTTPException(404, "Exam not found")
    return EXAMS[eid]


def _job(eid, sid, runs):
    exam, sheet = EXAMS[eid], EXAMS[eid]["sheets"][sid]
    try:
        sheet.update(status="processing", error="", progress="Reading the PDF")
        save()
        pdf = (DATA / "pdfs" / f"{sid}.pdf").read_bytes()
        process_sheet(exam, sheet, llm(), pdf, runs, save)
    except Exception as e:  # noqa
        sheet.update(status="failed", error=str(e)[:300], progress="")
    save()


@router.get("/exams")
def list_exams():
    return [{"id": k, "title": v["title"], "sheets": len(v["sheets"])} for k, v in EXAMS.items()]


@router.post("/exams")
def save_exam(body: dict):
    try: ex = normalize_exam(body)
    except (ValueError, KeyError, TypeError) as e: raise HTTPException(400, str(e))
    with LOCK:
        eid = body.get("id") if body.get("id") in EXAMS else uuid.uuid4().hex[:8]
        ex["id"], ex["sheets"] = eid, EXAMS.get(eid, {}).get("sheets", {})
        EXAMS[eid] = ex
        for s in ex["sheets"].values():
            if s["status"] == "done": finalize(s, ex)   # thresholds may have changed
        save()
    return {k: v for k, v in ex.items() if k != "sheets"}


@router.get("/exams/{eid}")
def read_exam(eid: str):
    e = get_exam(eid); return {k: v for k, v in e.items() if k != "sheets"}


@router.post("/exams/{eid}/sheets")
async def upload(eid: str, files: list[UploadFile] = File(...), meta: str = Form("[]"), runs: int = Form(1)):
    exam = get_exam(eid)
    meta = json.loads(meta or "[]")
    out = []
    for i, f in enumerate(files):
        data = await f.read()
        if not data.startswith(b"%PDF"): raise HTTPException(400, f"{f.filename} is not a PDF.")
        m = meta[i] if i < len(meta) else {}
        sid = uuid.uuid4().hex[:8]
        (DATA / "pdfs" / f"{sid}.pdf").write_bytes(data)
        exam["sheets"][sid] = {"id": sid, "filename": f.filename, "student_id": (m.get("student_id") or "").strip(),
                               "student_name": (m.get("student_name") or "").strip(), "status": "queued",
                               "runs": runs, "questions": {}, "uploaded": time.time()}
        POOL.submit(_job, eid, sid, max(1, min(runs, 5))); out.append(sid)
    save()
    return {"queued": out}


def _summary(s):
    keep = ("id", "filename", "student_id", "student_name", "status", "error", "progress", "total", "max_total",
            "percent", "result", "good", "needs_review", "notes")
    d = {k: s.get(k) for k in keep}
    d["marks"] = {q: {"marks": v["marks"], "counted": v.get("counted"), "flagged": v.get("flagged") and not v.get("edited")}
                  for q, v in s["questions"].items()}
    return d


@router.get("/exams/{eid}/results")
def results(eid: str):
    e = get_exam(eid)
    return {"exam": {k: v for k, v in e.items() if k != "sheets"}, "sheets": [_summary(s) for s in e["sheets"].values()]}


@router.get("/exams/{eid}/sheets/{sid}")
def sheet(eid: str, sid: str):
    s = get_exam(eid)["sheets"].get(sid) or (_ for _ in ()).throw(HTTPException(404, "Sheet not found"))
    slim = {q: {k: v for k, v in d.items() if k != "result"} | {
        "criteria": d["result"]["evaluation"]["criteria"], "feedback": d["result"]["evaluation"]["student_feedback"],
        "ocr_uncertainties": d["result"]["ocr_uncertainties"]} for q, d in s["questions"].items()}
    return _summary(s) | {"questions": slim}


@router.get("/exams/{eid}/sheets/{sid}/pdf")
def pdf(eid: str, sid: str):
    get_exam(eid)
    p = DATA / "pdfs" / f"{sid}.pdf"
    if not p.exists(): raise HTTPException(404, "PDF missing")
    return FileResponse(p, media_type="application/pdf")


class MarkEdit(BaseModel):
    question_id: str
    marks: float
    student_id: str | None = None
    student_name: str | None = None


@router.post("/exams/{eid}/sheets/{sid}/marks")
def edit_marks(eid: str, sid: str, b: MarkEdit):
    e = get_exam(eid); s = e["sheets"].get(sid)
    if s is None: raise HTTPException(404, "Sheet not found")
    d = s["questions"].get(b.question_id)
    if d is None: raise HTTPException(404, "Question not attempted")
    if not 0 <= b.marks <= d["max"]: raise HTTPException(400, f"Marks must be between 0 and {d['max']:g}")
    d["marks"], d["edited"] = b.marks, True
    finalize(s, e); save()
    return _summary(s)


@router.post("/exams/{eid}/sheets/{sid}/identity")
def edit_identity(eid: str, sid: str, b: dict):
    s = get_exam(eid)["sheets"].get(sid) or (_ for _ in ()).throw(HTTPException(404, "Sheet not found"))
    s["student_id"], s["student_name"] = str(b.get("student_id", "")).strip(), str(b.get("student_name", "")).strip()
    save(); return _summary(s)


@router.post("/exams/{eid}/sheets/{sid}/retry")
def retry(eid: str, sid: str):
    s = get_exam(eid)["sheets"].get(sid) or (_ for _ in ()).throw(HTTPException(404, "Sheet not found"))
    s.update(status="queued", error="")
    POOL.submit(_job, eid, sid, s.get("runs", 1)); save(); return {"ok": True}


@router.delete("/exams/{eid}/sheets/{sid}")
def delete_sheet(eid: str, sid: str):
    get_exam(eid)["sheets"].pop(sid, None)
    (DATA / "pdfs" / f"{sid}.pdf").unlink(missing_ok=True); save(); return {"ok": True}


@router.get("/exams/{eid}/export.xlsx")
def export(eid: str):
    e = get_exam(eid)
    return Response(build_workbook(e, list(e["sheets"].values())),
                    media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="{e["title"][:40].replace(" ", "_")}_marks.xlsx"'})
