"""Exam paper setup and "answer N of M" logic. Pure functions, no I/O."""

def normalize_exam(d: dict) -> dict:
    qs = d.get("questions") or []
    if not qs: raise ValueError("Add at least one question.")
    seen = set()
    for i, q in enumerate(qs, 1):
        q["id"] = str(q.get("id") or f"Q{i}").strip()
        if q["id"] in seen: raise ValueError(f"Duplicate question id {q['id']}.")
        seen.add(q["id"])
        q["max_marks"] = float(q.get("max_marks") or 0)
        if q["max_marks"] <= 0: raise ValueError(f"{q['id']}: marks must be above 0.")
        if not str(q.get("question", "")).strip(): raise ValueError(f"{q['id']}: question text is empty.")
        rub = [r for r in q.get("rubric") or [] if str(r.get("criterion", "")).strip()]
        for r in rub: r["max_marks"] = float(r["max_marks"])
        if not rub:
            rub = [{"criterion": "Overall correctness and completeness", "max_marks": q["max_marks"], "description": ""}]
        tot = sum(r["max_marks"] for r in rub)
        if abs(tot - q["max_marks"]) > 1e-6:
            raise ValueError(f"{q['id']}: rubric adds up to {tot:g} but the question is worth {q['max_marks']:g}.")
        q["rubric"] = rub
        q.setdefault("reference_answer", "")
    n = int(d.get("required_count") or len(qs))
    if not 1 <= n <= len(qs): raise ValueError("'Required questions' must be between 1 and the number of questions.")
    d["required_count"] = n
    d["pass_percent"] = float(d.get("pass_percent") or 40)
    d["good_percent"] = float(d.get("good_percent") or 75)
    if d["good_percent"] <= d["pass_percent"]: raise ValueError("'Good marks' must be above the pass mark.")
    d["extra_policy"] = d.get("extra_policy") if d.get("extra_policy") in ("best", "first") else "best"
    d["total_marks"] = sum(sorted((q["max_marks"] for q in qs), reverse=True)[:n])
    d.setdefault("title", "Untitled exam")
    return d


def pick_counted(attempted: list, n: int, policy: str) -> set:
    """attempted: [(qid, marks)] in order the student wrote them. Returns the qids that count."""
    if len(attempted) <= n: return {q for q, _ in attempted}
    if policy == "first": return {q for q, _ in attempted[:n]}
    ranked = sorted(enumerate(attempted), key=lambda t: (-t[1][1], t[0]))  # highest marks, earlier wins ties
    return {t[1][0] for t in ranked[:n]}


def finalize(sheet: dict, exam: dict) -> dict:
    """Recompute counted questions, totals, percent, result. Call after any marks change."""
    qs = sheet["questions"]
    order = [(q, d["marks"]) for q, d in qs.items() if d.get("attempted")]
    counted = pick_counted(order, exam["required_count"], exam["extra_policy"])
    for q, d in qs.items(): d["counted"] = q in counted
    total = round(sum(d["marks"] for q, d in qs.items() if d.get("counted")), 2)
    pct = round(100 * total / exam["total_marks"], 1) if exam["total_marks"] else 0
    notes = list(sheet.get("warnings", []))
    if len(order) < exam["required_count"]:
        notes.append(f"Attempted {len(order)} of {exam['required_count']} required questions.")
    if len(order) > exam["required_count"]:
        rule = "highest-scoring" if exam["extra_policy"] == "best" else "first"
        notes.append(f"Attempted {len(order)}; the {rule} {exam['required_count']} were counted.")
    sheet.update(total=total, max_total=exam["total_marks"], percent=pct,
                 result="PASS" if pct >= exam["pass_percent"] else "FAIL",
                 good=pct >= exam["good_percent"], notes=notes,
                 needs_review=any(d.get("flagged") and not d.get("edited") for d in qs.values() if d.get("attempted")) or bool(sheet.get("warnings")))
    return sheet
