"""Deterministic guardrails: the LLM proposes, this code enforces."""

def _num(x, default=0.0):
    try: return float(x)
    except (TypeError, ValueError): return default


def enforce(score: dict, rubric: list, max_marks: float) -> dict:
    """Clamp per-criterion marks, align criteria to the rubric, cap alt credit, recompute total."""
    by_name = {c["criterion"].strip().lower(): c for c in score.get("criteria", [])}
    criteria, warnings = [], []
    for r in rubric:
        c = by_name.get(r["criterion"].strip().lower())
        if c is None:
            warnings.append(f"criterion missing from model output: {r['criterion']}")
            c = {"criterion": r["criterion"], "marks_awarded": 0, "correctness": "ambiguous",
                 "understanding": "none", "student_evidence": "", "reason": "not scored by model"}
        raw = _num(c.get("marks_awarded"))
        c["maximum_marks"] = r["max_marks"]
        c["marks_awarded"] = min(max(raw, 0), r["max_marks"])
        if c["marks_awarded"] != raw:
            warnings.append(f"clamped '{r['criterion']}' from {raw} to {c['marks_awarded']}")
        criteria.append(c)
    base = sum(c["marks_awarded"] for c in criteria)
    gap = max(sum(r["max_marks"] for r in rubric) - base, 0)  # alt credit may only fill lost marks
    alt = score.get("alternative_valid_points", [])
    alt_raw = sum(max(_num(a.get("marks_awarded")), 0) for a in alt)
    alt_total = min(alt_raw, gap)
    if alt_total < alt_raw:
        warnings.append("alternative-point credit capped to marks lost elsewhere")
    score.update(criteria=criteria, alternative_credit=alt_total,
                 total_marks=round(min(base + alt_total, max_marks), 2),
                 maximum_marks=max_marks, validation_warnings=warnings)
    return score
