import io
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

RED, GREEN, AMBER, HEAD = "F8CBCB", "CDEBD3", "FFF0B8", "1F3A5F"


def build_workbook(exam: dict, sheets: list) -> bytes:
    wb = Workbook(); ws = wb.active; ws.title = "Marks"
    qs = exam["questions"]
    cols = ["Student ID", "Name"] + [q["id"] for q in qs] + ["Total", "Out of", "Percent", "Result", "Remarks"]
    ws.append(cols)
    ws.append(["", "Max marks"] + [q["max_marks"] for q in qs] + ["", exam["total_marks"], "", "", ""])
    thin = Side(style="thin", color="BBBBBB")
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor=HEAD)
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for c in ws[2]: c.font = Font(italic=True, color="555555"); c.alignment = Alignment(horizontal="center")
    nq = len(qs)
    for s in sorted(sheets, key=lambda x: (x.get("student_id") or "", x.get("student_name") or x.get("filename", ""))):
        if s.get("status") != "done":
            ws.append([s.get("student_id", ""), s.get("student_name") or s.get("filename", "")] + [""] * nq +
                      ["", "", "", "NOT MARKED", s.get("error") or "Processing"]); continue
        row = [s.get("student_id", ""), s.get("student_name") or s.get("filename", "")]
        for q in qs:
            d = s["questions"].get(q["id"])
            row.append(d["marks"] if d and d.get("attempted") else "-")
        remarks = list(s.get("notes", []))
        if s.get("needs_review"): remarks.append("Teacher review recommended")
        row += [s["total"], s["max_total"], s["percent"] / 100, s["result"] + (" (Good)" if s["good"] else ""), "; ".join(remarks)]
        ws.append(row)
        r = ws.max_row
        fill = RED if s["result"] == "FAIL" else GREEN if s["good"] else None
        for j in range(1, len(cols) + 1):
            c = ws.cell(r, j); c.border = Border(bottom=thin)
            if j > 2: c.alignment = Alignment(horizontal="center")
            if fill and j in (1, 2, nq + 3, nq + 4, nq + 5, nq + 6): c.fill = PatternFill("solid", fgColor=fill)
        for j, q in enumerate(qs, 3):   # attempted but not counted: grey strikethrough
            d = s["questions"].get(q["id"])
            if d and d.get("attempted") and not d.get("counted"):
                ws.cell(r, j).font = Font(color="888888", strike=True)
        ws.cell(r, nq + 5).number_format = "0.0%"
        ws.cell(r, nq + 6).font = Font(bold=True, color="9C0006" if s["result"] == "FAIL" else "1E6B34")
        if s.get("needs_review"): ws.cell(r, nq + 7).fill = PatternFill("solid", fgColor=AMBER)
    ws.freeze_panes = "C3"
    for j in range(1, len(cols) + 1):
        ws.column_dimensions[get_column_letter(j)].width = 14 if 2 < j < nq + 7 else 18 if j < 3 else 50
    ws.column_dimensions["B"].width = 26

    sm = wb.create_sheet("Summary")
    done = [s for s in sheets if s.get("status") == "done"]
    n = len(done) or 1
    rows = [("Exam", exam["title"]), ("Questions to answer", f"{exam['required_count']} of {len(qs)}"),
            ("Counting rule if extra answered", "Highest marks" if exam["extra_policy"] == "best" else "First answered"),
            ("Pass mark", f"{exam['pass_percent']:g}%"), ("Good marks from", f"{exam['good_percent']:g}%"), ("", ""),
            ("Sheets marked", len(done)), ("Passed", sum(s["result"] == "PASS" for s in done)),
            ("Failed", sum(s["result"] == "FAIL" for s in done)), ("Good marks", sum(s["good"] for s in done)),
            ("Average percent", round(sum(s["percent"] for s in done) / n, 1)), ("", ""),
            ("Key", ""), ("Red rows", "Failed"), ("Green rows", "Good marks"),
            ("Yellow remarks", "AI flagged; a teacher should check"), ("Grey struck-through mark", "Answered but not counted")]
    for r in rows: sm.append(list(r))
    sm.column_dimensions["A"].width = 34; sm.column_dimensions["B"].width = 40
    for r in (1, 13): sm.cell(r, 1).font = Font(bold=True)
    for r, col in ((14, RED), (15, GREEN), (16, AMBER)): sm.cell(r, 1).fill = PatternFill("solid", fgColor=col)
    buf = io.BytesIO(); wb.save(buf); return buf.getvalue()
