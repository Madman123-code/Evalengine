import json, re
from typing import Protocol


class LLM(Protocol):
    def complete_json(self, stage: str, system: str, user: str) -> dict: ...


def parse_json(text: str) -> dict:
    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
    return json.loads(text)


class AnthropicLLM:
    def __init__(self, model: str = "claude-sonnet-5-5", temperature: float = 0.3):
        import anthropic
        self.client, self.model, self.temp = anthropic.Anthropic(), model, temperature

    def complete_json(self, stage, system, user):
        for attempt in range(2):
            r = self.client.messages.create(
                model=self.model, max_tokens=4000, temperature=self.temp,
                system=system, messages=[{"role": "user", "content": user}])
            try:
                return parse_json(r.content[0].text)
            except json.JSONDecodeError:
                user += "\n\nYour last reply was not valid JSON. Return ONLY the JSON object."
        raise ValueError(f"{stage}: model did not return valid JSON")


def _anthropic_pdf(self, stage, system, prompt, pdf: bytes):
    import base64
    r = self.client.messages.create(
        model=self.model, max_tokens=8000, temperature=0, system=system,
        messages=[{"role": "user", "content": [
            {"type": "document", "source": {"type": "base64", "media_type": "application/pdf",
                                            "data": base64.b64encode(pdf).decode()}},
            {"type": "text", "text": prompt}]}])
    return parse_json(r.content[0].text)


AnthropicLLM.read_pdf_json = _anthropic_pdf


class MockLLM:
    """Canned responses per stage; a stage value may be a list (cycled per call) for testing."""
    def __init__(self, responses):
        self.r, self.calls = responses, {}

    def complete_json(self, stage, system, user):
        v = self.r[stage]
        if isinstance(v, list):
            i = self.calls.get(stage, 0); self.calls[stage] = i + 1
            v = v[i % len(v)]
        return json.loads(json.dumps(v))

    def read_pdf_json(self, stage, system, prompt, pdf):
        return self.complete_json(stage, system, prompt)


class GeminiLLM:
    """Free-tier friendly. Key from https://aistudio.google.com (env GEMINI_API_KEY).
    Retries overloads (503/429) with backoff and falls back to other models."""
    FALLBACKS = ["gemini-flash-lite-latest", "gemini-2.5-flash"]
    TRANSIENT = ("429", "500", "502", "503", "504", "UNAVAILABLE", "RESOURCE_EXHAUSTED", "DEADLINE")

    def __init__(self, model=None, temperature: float = 0.3):
        import os
        from google import genai
        self.client = genai.Client()  # reads GEMINI_API_KEY / GOOGLE_API_KEY
        primary = model or os.getenv("GEMINI_MODEL", "gemini-flash-latest")
        self.models = [primary] + [m for m in self.FALLBACKS if m != primary]
        self.temp = temperature

    def complete_json(self, stage, system, user):
        return self._call(stage, system, user)

    def read_pdf_json(self, stage, system, prompt, pdf: bytes):
        from google.genai import types
        return self._call(stage, system, [types.Part.from_bytes(data=pdf, mime_type="application/pdf"), prompt])

    def _call(self, stage, system, contents):
        import time
        from google.genai import types
        cfg = types.GenerateContentConfig(system_instruction=system, temperature=self.temp,
                                          response_mime_type="application/json")
        last, mi = None, 0
        for attempt in range(8):
            try:
                r = self.client.models.generate_content(model=self.models[mi], contents=contents, config=cfg)
                return parse_json(r.text)
            except Exception as e:  # noqa
                last, msg = e, str(e)
                if "404" in msg or "NOT_FOUND" in msg:      # model name unavailable: next model now
                    mi = min(mi + 1, len(self.models) - 1); continue
                transient = any(t in msg for t in self.TRANSIENT)
                if transient and attempt % 2 == 1:           # overloaded twice: try the next model
                    mi = min(mi + 1, len(self.models) - 1)
                print(f"[gemini] {stage} attempt {attempt+1} on {self.models[mi]} failed: {msg[:120]}")
                time.sleep(min(4 * 2 ** attempt, 30) if transient else 1)
        raise ValueError(f"{stage}: Gemini call failed after retries: {last}")


def make_llm():
    import os
    return AnthropicLLM() if os.getenv("LLM_PROVIDER", "gemini").lower() == "anthropic" else GeminiLLM()
