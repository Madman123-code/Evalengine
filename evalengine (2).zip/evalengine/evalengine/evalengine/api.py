"""Run: uvicorn evalengine.api:app --reload   (needs GEMINI_API_KEY, or LLM_PROVIDER=anthropic + ANTHROPIC_API_KEY)"""
import json, uuid, pathlib
from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.responses import FileResponse
from pydantic import BaseModel
from .pipeline import evaluate
from .llm import make_llm
from .ocr import make_ocr

app = FastAPI(title="Fair Exam Evaluator")
from .exam_api import router as exam_router
app.include_router(exam_router)
DB = pathlib.Path("reviews.json")
STORE: dict = json.loads(DB.read_text()) if DB.exists() else {}
_llm = _ocr = None


def llm():
    global _llm
    _llm = _llm or make_llm()
    return _llm


def save(): DB.write_text(json.dumps(STORE, indent=1))


class Criterion(BaseModel):
    criterion: str
    max_marks: float
    description: str = ""


class EvalReq(BaseModel):
    question_id: str
    question: str
    max_marks: float
    rubric: list[Criterion]
    student_answer: str
    reference_answer: str = ""
    subject: str = ""
    question_type: str = ""


def _run(req: dict, ocr_conf=1.0):
    res = evaluate(req, llm(), ocr_confidence=ocr_conf)
    rid = uuid.uuid4().hex[:8]
    res["id"] = rid
    STORE[rid] = {"request": req, "result": res, "history": []}
    save()
    return res


@app.post("/evaluate")
def evaluate_text(r: EvalReq): return _run(r.model_dump())


@app.post("/evaluate-image")
async def evaluate_image(question_id: str = Form(...), question: str = Form(...), max_marks: float = Form(...),
                         rubric_json: str = Form(...), reference_answer: str = Form(""),
                         image: UploadFile = File(...)):
    global _ocr
    _ocr = _ocr or make_ocr()
    o = _ocr.read(await image.read(), image.content_type or "image/jpeg")
    return _run(dict(question_id=question_id, question=question, max_marks=max_marks,
                     rubric=json.loads(rubric_json), reference_answer=reference_answer,
                     student_answer=o.text), o.confidence)


@app.get("/reviews")
def queue(flagged_only: bool = True):
    return [v["result"] | {"student_answer": v["request"]["student_answer"]} for v in STORE.values()
            if v["result"]["status"] not in ("final",) and (v["result"]["human_review_required"] or not flagged_only)]


class Action(BaseModel):
    action: str  # ACCEPT | MODIFY_MARKS | OVERRIDE | ADD_COMMENT | SECOND_REVIEW
    marks: float | None = None
    comment: str = ""
    reviewer: str = "teacher"


@app.post("/reviews/{rid}")
def review(rid: str, a: Action):
    rec = STORE.get(rid)
    if rec is None: raise HTTPException(404, "not found")
    res = rec["result"]
    mx = res["maximum_marks"]
    if a.action in ("MODIFY_MARKS", "OVERRIDE"):
        if a.marks is None or not 0 <= a.marks <= mx: raise HTTPException(400, f"marks must be 0-{mx}")
        rec["history"].append({"from": res["total_marks"], "to": a.marks, **a.model_dump()})
        res["total_marks"] = a.marks
    else:
        rec["history"].append(a.model_dump())
    res["status"] = ("second_review" if a.action == "SECOND_REVIEW"
                     else "commented" if a.action == "ADD_COMMENT" else "final")
    save()
    return res


@app.get("/")
def ui(): return FileResponse(pathlib.Path(__file__).parent.parent / "static" / "index.html")


@app.get("/review")
def old_review(): return FileResponse(pathlib.Path(__file__).parent.parent / "static" / "review.html")
