"""OCR adapter. Returns text plus a 0-1 confidence so low quality can trigger human review.
Swap in Google Vision / Azure Read / TrOCR by implementing `read`."""
from dataclasses import dataclass


@dataclass
class OCRResult:
    text: str
    confidence: float  # mean confidence, 0-1


class PassthroughOCR:
    """For already-typed answers (and tests)."""
    def read(self, data) -> OCRResult:
        return OCRResult(data.decode() if isinstance(data, bytes) else data, 1.0)


class ClaudeVisionOCR:
    """Transcribes handwritten images with Claude. Confidence is a rough proxy from [illegible] markers."""
    def __init__(self, model="claude-sonnet-5-5"):
        import anthropic
        self.client, self.model = anthropic.Anthropic(), model

    def read(self, image_bytes: bytes, media_type="image/jpeg") -> OCRResult:
        import base64
        b64 = base64.b64encode(image_bytes).decode()
        r = self.client.messages.create(
            model=self.model, max_tokens=3000,
            messages=[{"role": "user", "content": [
                {"type": "image", "source": {"type": "base64", "media_type": media_type, "data": b64}},
                {"type": "text", "text": "Transcribe this handwritten answer exactly, without correcting "
                 "mistakes. Write [illegible] for any unreadable word. Output only the transcription."}]}])
        text = r.content[0].text
        words = max(len(text.split()), 1)
        return OCRResult(text, max(0.0, 1 - 5 * text.count("[illegible]") / words))


class GeminiVisionOCR:
    """Handwriting transcription with Gemini (free tier)."""
    def __init__(self, model=None):
        import os
        from google import genai
        self.client = genai.Client()
        self.model = model or os.getenv("GEMINI_MODEL", "gemini-flash-latest")

    def read(self, image_bytes: bytes, media_type="image/jpeg") -> OCRResult:
        from google.genai import types
        r = self.client.models.generate_content(model=self.model, contents=[
            types.Part.from_bytes(data=image_bytes, mime_type=media_type),
            "Transcribe this handwritten answer exactly, without correcting mistakes. "
            "Write [illegible] for any unreadable word. Output only the transcription."])
        text = r.text or ""
        words = max(len(text.split()), 1)
        return OCRResult(text, max(0.0, 1 - 5 * text.count("[illegible]") / words))


def make_ocr():
    import os
    return ClaudeVisionOCR() if os.getenv("LLM_PROVIDER", "gemini").lower() == "anthropic" else GeminiVisionOCR()
