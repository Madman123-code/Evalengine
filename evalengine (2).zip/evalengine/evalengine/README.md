# Fair Exam Evaluator

Pipeline: OCR -> **Extract claims** -> **Rubric scoring x3** -> **Fairness audit** -> deterministic validation -> teacher review.

Design choices
- LLM proposes, code disposes: per-criterion caps, alt-credit cap, and totals are enforced in `validate.py`.
- Confidence comes from objective signals (run disagreement, OCR confidence, audit issues), not model self-report.
- Student text is untrusted: wrapped in `<student_answer>` tags, injection attempts are flagged.
- Teacher is final authority: ACCEPT / MODIFY_MARKS / OVERRIDE / ADD_COMMENT / SECOND_REVIEW, with history kept.

Run
    pip install -r requirements.txt
    # Free: key from https://aistudio.google.com -> GEMINI_API_KEY (optional GEMINI_MODEL)
    # Paid alternative: LLM_PROVIDER=anthropic and ANTHROPIC_API_KEY
    uvicorn evalengine.api:app --reload      # review UI at http://localhost:8000
    python -m unittest                       # offline tests (mock LLM)

Swap providers by implementing `complete_json(stage, system, user)` (see `llm.py`); swap OCR via `ocr.py`.
Next steps: calibrate thresholds against teacher-graded data, add paraphrase-consistency tests, real DB + auth.

## Answer sheets, "answer N of M", Excel
Open http://localhost:8000 -> 1 Set up paper -> 2 Add answer sheets (PDFs) -> 3 Results -> Download Excel.
- Paper: any number of questions, students answer N of them. If they answer extra, the highest-scoring N (or the first N) count.
- Pass mark and "good marks" thresholds decide the red / green highlighting (UI and Excel).
- PDFs are read directly by the model (handwriting transcription + splitting by question number).
- Data is kept in ./data (exams.json + the uploaded PDFs). Set EVAL_WORKERS to mark several sheets at once (mind API limits).
- Old single-answer review page: /review
