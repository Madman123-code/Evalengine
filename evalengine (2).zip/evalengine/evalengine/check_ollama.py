"""Run:  python check_ollama.py   - confirms Ollama is running and the models are installed."""
import json, os, urllib.request
host = os.getenv("OLLAMA_HOST", "http://localhost:11434"); host = host if host.startswith("http") else "http://" + host
need = {"marking": os.getenv("OLLAMA_MODEL", "qwen2.5:7b"), "reading handwriting": os.getenv("OLLAMA_VISION_MODEL", "qwen2.5vl:7b")}
try:
    have = [m["name"] for m in json.load(urllib.request.urlopen(host + "/api/tags", timeout=5))["models"]]
except Exception as e:
    raise SystemExit(f"Cannot reach Ollama at {host} ({e}).\nInstall it from https://ollama.com/download and make sure it is running.")
print("Ollama is running. Installed models:", ", ".join(have) or "none")
for what, m in need.items():
    ok = any(h == m or h.split(":")[0] == m or h == m + ":latest" for h in have)
    print(f"  {'OK     ' if ok else 'MISSING'} {m}  (used for {what})" + ("" if ok else f"   ->  ollama pull {m}"))
try: import fitz; print("  OK      PyMuPDF (PDF page rendering)")
except ImportError: print("  MISSING PyMuPDF   ->  pip install pymupdf")
